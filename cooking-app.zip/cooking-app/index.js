/**
 * Author: Joseph Sarno
 * Date: 06/07/2024
 * File Name: index
 * Description: Demonstrates the use of the recipes module
 */

// TODO: Import your module using require
const { createRecipe, setTimer, quit } = require('./recipes');

// TODO: Implement your CLI program here
const ingredients = ['flour', 'sugar', 'eggs'];
console.log(createRecipe(ingredients));

const minutes = 30;
console.log(setTimer(minutes));

console.log(quit());
