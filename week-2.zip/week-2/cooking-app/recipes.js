/**
 * Author: Joseph Sarno
 * Date: 06/07/2024
 * File Name: recipes
 * Description: recipes
 */

// Define the createRecipe function
function createRecipe(ingredients) {
  return `Recipe created with ingredients: ${ingredients.join(', ')}`;
}

// Define the setTimer function
function setTimer(minutes) {
  return `Timer set for ${minutes} minutes.`;
}

// Define the quit function
function quit() {
  return 'Program exited';
}

// Export the functions
module.exports = {
  createRecipe,
  setTimer,
  quit,
};
